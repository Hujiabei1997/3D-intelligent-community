var sql = require('mssql');

// DB configuration
var dbConfig = {
  user: 'sa',
  password: 'hjb971209',
  server: 'localhost',
  database: 'sde',
  port: 3306,
 
};

// 查询所有的用户信息
function getAllUsers() {
  var conn = new sql.ConnectionPool(dbConfig);
  //console.log(conn);
  var req = new sql.Request(conn);
  conn.connect(function (err) {
      if (err) {
          console.log(err);
          return;
      }
      // 查询t_user表
      req.query("SELECT * FROM 住宅楼", function (err, recordset) {
          if (err) {
              console.log(err);
              return;
          }
          else {
              console.log(recordset);
          }
          conn.close();
      });
  });
  }
  
// 查询所有的用户信息
getAllUsers();
